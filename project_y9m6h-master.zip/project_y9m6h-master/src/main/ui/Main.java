package ui;

// runs the flashcardAppUI class
public class Main {
    public static void main(String[] args) {
        FlashCardApp flashCardApp = new FlashCardApp();
    }
}

